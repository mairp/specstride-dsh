# Dependencies of `@specstride/contracts`

Pinned at T005 (F100-FR-027: every dependency of a published package is declared
at an exact version, never a range; F100-FR-029: every dependency is compatible
with MIT). The validator is the one of `research.md`, decision D-2: Ajv, the only
runtime dependency of this package.

## The runtime dependency

| Dependency | Exact version                                 | Licence | Install script | Native part |
| ---------- | --------------------------------------------- | ------- | -------------- | ----------- |
| `ajv`      | `8.20.0` (declared exactly in `package.json`) | MIT     | none           | none        |

Verified on 2026-09-30 from the installed package (its `package.json` and its
`LICENSE` file, never its source):

- **Version and licence**: `node_modules/ajv/package.json` holds `version: 8.20.0`
  and `license: MIT`; `node_modules/ajv/LICENSE` is "The MIT License (MIT)",
  "Copyright (c) 2015-2021 Evgeny Poberezkin".
- **No install script**: the `scripts` of the installed `package.json` hold only
  development and publishing scripts (`eslint`, `prettier:*`, `test*`, `build`,
  `bundle`, `rollup`, `json-tests`, `prepublish`, `benchmark`, `docs:*`); none of
  `preinstall`, `install`, `postinstall` or `prepare` is present, so
  `npm install --ignore-scripts` and a plain `npm install` behave the same for it.
- **No native part**: no `binding.gyp`, no `gypfile` field, no `optionalDependencies`,
  and no `.node` file anywhere in the installed tree of `ajv` and its dependencies.
- **Draft 2020-12**: the package exports `ajv/dist/2020` (`Ajv2020`); a compiled
  2020-12 schema validated a conforming record and refused a non-conforming one.

## Its transitive dependencies (all MIT-compatible, none with an install script)

| Dependency (installed version) | Licence                            | Install script |
| ------------------------------ | ---------------------------------- | -------------- |
| `fast-deep-equal` 3.1.3        | MIT                                | none           |
| `fast-uri` 3.1.8               | BSD-3-Clause (compatible with MIT) | none           |
| `json-schema-traverse` 1.0.0   | MIT                                | none           |
| `require-from-string` 2.0.2    | MIT                                | none           |

All four are pure JavaScript and are declared by `ajv` itself, not by this
package; their licences are compatible with MIT (F100-FR-029).

## Note on the workspace tree

The workspace root declares `eslint` as a development dependency; `eslint` pulls
its own `ajv` 6.15.0 (MIT) into the top of `node_modules/`. That copy is a
transitive development dependency of the workspace, not a dependency of this
package, and no published package of the product depends on it.
