# `@specstride/testkit`

The test kit of Specstride: the **frame** in which every content owner places the conformance suite
and the sample of its extension point, the **static tests**, the **table-level tests** and the
**canary harness** (feature 100, F100-FR-017, F100-FR-018, F100-FR-222 to F100-FR-226).

This README is for an **author of a later implementation** — a package of a Wave 1 feature, or a
consumer's own data implementation, that must pass the suite of an extension point.

Feature 100 builds the frame, the runner, the report, and for each of the nineteen points a
contract-level suite that checks what the annex states with **no behaviour**: the operations exist,
results stay inside the closed result set, a throwing implementation degrades to the documented
path, an unknown value is handled by the stated rule. **The cases that need behaviour are added by
the content owner** (`research.md`, D-10).

```
src/conformance/            the frame: the registries, the runner, the degradation, the samples
src/conformance/EP-nn/      the cases of one point: contract-level (feature 100) and behaviour (its owner)
src/samples/EP-nn/          the sample implementation of one point, outside the core
src/static/                 the static tests (script `test:static`)
src/tables/                 the table-level tests (script `test:tables`)
src/canary/                 the canary harness (script `test:canary`)
```

## How to register an implementation of an extension point

There is **one registry per point**, filled at process start and read-only after launch
(F100-FR-016). Offer an implementation to it; the outcome says what the registry did.

```ts
import { registryOf, type Implementation } from "@specstride/testkit";

const implementation: Implementation = {
  ep: "EP-08",
  pointId: "specstride.event-sink/1",
  id: "my-event-sink",
  implementationClass: "first-party", // "data" | "first-party" | "third-party"
  majors: [1], // the majors it declares it supports (F100-FR-013)
  provenance: "default", // the configuration rank the registration came from (annex X §X.2)
  operations: {/* open, write, flush, close, status */},
};

const outcome = registryOf("specstride.event-sink/1").register(implementation);
if (!outcome.accepted) {
  outcome.reason; // "third-party-class" | "major-out-of-range" | "data-invalid" | …
  outcome.message; // what the launch prints
  outcome.doctorWarning; // what the doctor shows, where the rule asks for one
}
```

The rules the registry holds you to:

| Rule                                  | What happens                                                                                                                                                                                                              |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| The **class** (F100-FR-014)           | `data` is validated against the schema id you give (`schemaId`, `value`); `first-party` is accepted; `third-party` is **refused in Wave 1** with a message that names the class                                           |
| The **range of majors** (F100-FR-013) | The core supports the current major and the one before. An implementation outside the range is refused, and the doctor reports it                                                                                         |
| **Widening** (F100-FR-015)            | An implementation that widens capability is accepted from user configuration, the environment or a flag only. From project configuration it is **ignored** with a launch message and a doctor warning; the launch goes on |
| **Frozen after launch** (F100-FR-016) | After `markLaunched()` a registration is refused with the reason `frozen`. What the run resolved is in `resolved()`, which it writes to its records and replays on resume                                                 |

A **data** implementation carries `schemaId` and `value` instead of `operations`, and is validated
when it is loaded:

```ts
registryOf("specstride.harness/1").register({
  ep: "EP-02",
  pointId: "specstride.harness/1",
  id: "my-harness-descriptor",
  implementationClass: "data",
  majors: [1],
  provenance: "user",
  schemaId: "specstride.harness/1:descriptor",
  value: theDescriptorYouParsed,
});
```

## How to run its conformance suite on request

`runSuite` runs the cases of the point on a registered implementation and reports per case. It
registers the implementation itself where you have not, so that a **consumer can run the suite on a
data implementation on request** (F100-FR-017).

```ts
import { runSuite, lineOf } from "@specstride/testkit";
import { cases } from "@specstride/testkit/conformance/EP-08";

const report = await runSuite("specstride.event-sink/1", implementation, cases);
report.passed; // true when every case passed
console.log(lineOf(report));
// EP-08 specstride.event-sink/1 major 1 impl=my-event-sink class=first-party: 10/10 cases passed
```

From the command line, the script `conformance` of this package runs the suite of every point on
its sample, or of one point when you name it:

```
npm run conformance --workspace @specstride/testkit            # all nineteen points
npm run conformance --workspace @specstride/testkit -- EP-08   # one point
```

```
EP-08 specstride.event-sink/1 major 1 impl=sample-event-sink-memory class=first-party: 10/10 cases passed
conformance: 1 point(s) of 19, 10 case(s), 0 failure(s)
```

Asking for a suite on an implementation the registry did not accept throws
`ImplementationNotRegisteredError` with the reason — a suite never runs on an unregistered
implementation.

## How the report reads

| Field of `SuiteReport`                    | What it holds                                                                                                                                                  |
| ----------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ep`, `pointId`                           | The point and the id of the interface, `EP-08` and `specstride.event-sink/1`                                                                                   |
| `implementationId`, `implementationClass` | Which implementation ran, and its class                                                                                                                        |
| `major`                                   | The major in force: the highest declared major the core supports                                                                                               |
| `standing`, `internalSeam`                | `public-contract` for EP-01 to EP-17 and EP-19; `internal-seam` for **EP-18**, which is marked in the report (F100-FR-020)                                     |
| `cases`                                   | One `CaseReport` per case: `caseId`, `title`, `level` (`contract` or `behaviour`), `proves` (the requirements), `passed`, `message` on a failure, `durationMs` |
| `passed`                                  | True when every case passed                                                                                                                                    |

A **failing implementation** never produces a verdict, an exit code or a stop reason of its own. The
wrapper of `src/conformance/degrade.ts` catches a throw, a time limit and a result outside the
closed result set of the point, takes the plainer path that the point's file documents under
"Failure of an implementation", and records the degradation as an event of the envelope
(F100-FR-019). The cause is one of `threw`, `time-limit`, `outside-result-set`.

## How the content owner adds behaviour cases in the folder of its point

The folder of a point, `src/conformance/EP-nn/`, holds the contract-level cases of feature 100 and
the behaviour cases of the content owner **side by side**. A module of the folder exports `cases`,
an array of `ConformanceCase`:

```ts
// packages/testkit/src/conformance/EP-08/behaviour.test.ts  — owner: feature 111
import { casesAsTests, type ConformanceCase } from "@specstride/testkit";
import { implementation } from "../../samples/EP-08/index.ts";

export const cases: readonly ConformanceCase[] = [
  {
    id: "CT-111-014", // the owner's own id, not a CT-100-*
    title: "an event of an unknown type is ignored and the sink stays open",
    level: "behaviour", // the level of the case: `contract` is feature 100's
    proves: ["F111-FR-009"],
    run(impl) {
      // Throws on a failure, as `node:assert` does.
    },
  },
];

await casesAsTests("specstride.event-sink/1", implementation, cases);
```

`casesAsTests` registers each case as a test of `node:test`, so the same cases run under
`npm test` and under the script `conformance`; while the script produces the report it registers
no test (`inReportMode()`).

Two rules bind the folder:

- **The sample lives outside the core.** `src/samples/EP-nn/index.ts` is registered from the test
  tree by `registerSamples()`, so **no core file names a sample**, and adding or removing a sample
  changes no core file (F100-FR-018). The import-boundary check fails and names the file if a core
  file does name one.
- **A case states what it proves.** `proves` carries the requirement ids; the acceptance run of
  F100-FR-222 reports them.

## How the static, the table and the canary tests are run

```
npm run test:static  --workspace @specstride/testkit   # the static tests
npm run test:tables  --workspace @specstride/testkit   # one test per row of the data tables
npm run test:canary  --workspace @specstride/testkit   # the canary harness
npm test             --workspace @specstride/testkit   # the frame, the suites and the samples
```

**The static tests** (`src/static/index.ts`, F100-FR-225, F100-FR-226) read the specifications
under `specs/1*/` and the `contracts` package, and report each check as one test:

| Check                     | Passes when                                                                                                                       |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Closed sets               | Every closed set the `contracts` package exports has a row in `closed-sets.json`, and the reverse                                 |
| Schema field              | Every logical name of the control plane whose content is a record has a schema with a required `schema` property                  |
| Profile                   | Every switch a package registers has a row in `parity-profile.json` with a value under `parity`                                   |
| Logical names             | Every logical name has a path, a root and exactly one writer                                                                      |
| Physical paths            | No specification under `specs/1*` names a path of `layout.json` outside `plan.md` and `contracts/`                                |
| Vocabulary                | No specification names an exit code, stop reason, run state, logical name, envelope field or rank the data files do not hold      |
| Product rules             | The never-bare terms are qualified; no requirement lists harness names; the packaging, licence and language rules of annex A §A.5 |
| Threat model, no listener | Every threat has an owner and a control; no package opens a network listener                                                      |

The run is **scoped** by the environment variable `TESTKIT_STATIC_SCOPE` (feature folder names
separated by commas; unset or empty means every feature). The checks that read the specifications
take the named folders as their subject and still read every folder as reference; a named folder
that does not exist fails the run. The checks of the `contracts` package are never scoped.

```
TESTKIT_STATIC_SCOPE=100-specstride npm run test:static --workspace @specstride/testkit
```

**The table-level tests** (`src/tables/`) are generated from the data files: one test per row of
every exit-code table, per stop reason (15) and per transition of the run-state machine (18), each
asserting the row against the exports of the `contracts` package. 100 per cent of the rows are
covered (F100-SC-009).

**The canary harness** (`src/canary/`) plants seven distinct canary secrets — in the prompt, the
reply of the model, tool arguments, tool output, phase evidence, the output of a check and the
consumer's comment — through a stub harness and a stub check runner, then scans every sink (the
event file, the exporters, the digest line, the status output, the payload of the read model) for
each planted value. **Zero hits is the pass** (F100-SC-008, F100-FR-219). In feature 100 the run is
against the sample sink and a **stub** redactor that replaces exact values, so it proves routing,
not coverage; feature 111 runs the same harness against the real redactor, and that run is the
release condition.

## Where the details are

| Subject                                                                              | File                                                                                             |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------ |
| The interface of each point                                                          | `packages/contracts/src/ep/`, and `specs/100-specstride/contracts/extension-points/EP-nn.*.json` |
| The thirteen sub-sections of a point, word for word                                  | the same JSON file, key `sections`                                                               |
| Validating a record, reading a closed set, a logical name, an exit code, the profile | `packages/contracts/README.md`                                                                   |
| Which feature owns which point                                                       | annex A §A.4, and the key `Content owner` of the point's file                                    |
